# control_risk_regression
Code for simulation section in Likelihood-based inference in control risk regression with additional covariates paper
